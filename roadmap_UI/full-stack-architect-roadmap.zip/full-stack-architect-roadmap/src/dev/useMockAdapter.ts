/**
 * Dev Mock Adapter — Provides mock ViewModels for standalone development.
 *
 * ❌ This file does NOT ship to the main project.
 * ✅ It exists only so `npm run dev` works standalone.
 *
 * This adapter simulates what useRoadmapGeneration + Zustand + selectors
 * would provide. It converts the raw mock data into ViewModels.
 */

import { useState, useCallback, useMemo } from "react";
import type {
  RoadmapPageProps,
  TaskType,
  TaskState,
  TopicView,
  SubtopicView,
  TaskView,
  TaskDetailView,
  FocusTaskView,
  DailyPlanView,
  MomentumView,
  WeeklySummaryView,
  TaskResource,
  ActionResult,
  RoadmapAction,
} from "../types";

// ─── Raw mock data (internal to dev only) ─────────────────────────────

interface RawTask {
  id: string;
  title: string;
  description: string;
  type: TaskType;
  estimatedTime: string;
  state: TaskState;
  isRecommended?: boolean;
  dependsOn?: string[];
  resources?: TaskResource[];
  skills?: string[];
}

interface RawSubtopic {
  id: string;
  title: string;
  tasks: RawTask[];
}

interface RawTopic {
  id: string;
  title: string;
  subtopics: RawSubtopic[];
}

const INITIAL_ROADMAP: RawTopic[] = [
  {
    id: "topic-1",
    title: "Web Foundations",
    subtopics: [
      {
        id: "sub-1-1",
        title: "HTML5 & Semantic Markup",
        tasks: [
          { id: "t-1", title: "Document Structure & DOCTYPE", description: "Learn the building blocks of every web page — the DOCTYPE declaration, html, head, and body tags. Understand how browsers parse and render HTML documents from top to bottom.", type: "learn", estimatedTime: "1h", state: "completed", skills: ["HTML5", "Web Basics"], resources: [{ title: "MDN: HTML Basics", url: "https://developer.mozilla.org/en-US/docs/Learn/HTML", type: "docs" }, { title: "HTML Crash Course", url: "https://www.youtube.com/watch?v=UB1O30fR-EE", type: "video" }] },
          { id: "t-2", title: "Semantic Elements (header, nav, article)", description: "Master semantic HTML elements that give meaning to your page structure. Learn when to use header, nav, main, section, article, aside, and footer for better accessibility and SEO.", type: "learn", estimatedTime: "1.5h", state: "completed", dependsOn: ["t-1"], skills: ["HTML5", "Accessibility", "SEO"], resources: [{ title: "Semantic HTML Guide", url: "https://web.dev/learn/html/semantic-html/", type: "article" }] },
          { id: "t-3", title: "Forms, Inputs & Validation", description: "Build interactive forms with various input types, implement client-side validation using built-in HTML5 constraints and the Constraint Validation API.", type: "practice", estimatedTime: "2h", state: "completed", dependsOn: ["t-2"], skills: ["HTML5", "Forms", "Validation"] },
          { id: "t-4", title: "Build a Multi-Page Portfolio Site", description: "Apply your HTML knowledge to build a complete multi-page portfolio website with proper navigation, semantic structure, and accessible forms.", type: "project", estimatedTime: "4h", state: "completed", dependsOn: ["t-3"], skills: ["HTML5", "Web Design"] },
        ],
      },
      {
        id: "sub-1-2",
        title: "CSS3 & Responsive Design",
        tasks: [
          { id: "t-5", title: "Box Model, Selectors & Specificity", description: "Understand how every element is a box with content, padding, border, and margin. Master CSS selectors from simple to complex and learn how specificity determines which styles win.", type: "learn", estimatedTime: "2h", state: "completed", skills: ["CSS3", "Layout"], resources: [{ title: "CSS Box Model Interactive", url: "https://developer.mozilla.org/en-US/docs/Learn/CSS/Building_blocks/The_box_model", type: "docs" }] },
          { id: "t-6", title: "Flexbox & CSS Grid Layouts", description: "Master the two most powerful CSS layout systems. Use Flexbox for one-dimensional layouts and CSS Grid for two-dimensional layouts.", type: "practice", estimatedTime: "3h", state: "completed", dependsOn: ["t-5"], skills: ["CSS3", "Flexbox", "CSS Grid"] },
          { id: "t-7", title: "Media Queries & Mobile-First Design", description: "Learn to create responsive designs that adapt to any screen size. Implement mobile-first methodology.", type: "learn", estimatedTime: "1.5h", state: "completed", dependsOn: ["t-6"], skills: ["CSS3", "Responsive Design"] },
          { id: "t-8", title: "CSS Animations & Transitions", description: "Add life to your interfaces with CSS transitions for smooth state changes and keyframe animations for complex motion.", type: "practice", estimatedTime: "2h", state: "completed", dependsOn: ["t-7"], skills: ["CSS3", "Animations", "UX"] },
        ],
      },
      {
        id: "sub-1-3",
        title: "Version Control with Git",
        tasks: [
          { id: "t-9", title: "Git Basics: Init, Add, Commit, Branch", description: "Set up Git repositories, track files, create meaningful commits, and use branches.", type: "learn", estimatedTime: "1.5h", state: "completed", skills: ["Git", "Version Control"], resources: [{ title: "Git Handbook", url: "https://guides.github.com/introduction/git-handbook/", type: "docs" }] },
          { id: "t-10", title: "GitHub: Pull Requests & Code Review", description: "Learn collaborative development workflows using GitHub. Create pull requests, review code, resolve merge conflicts.", type: "practice", estimatedTime: "2h", state: "completed", dependsOn: ["t-9"], skills: ["Git", "GitHub", "Collaboration"] },
        ],
      },
    ],
  },
  {
    id: "topic-2",
    title: "JavaScript Mastery",
    subtopics: [
      {
        id: "sub-2-1",
        title: "Core JavaScript",
        tasks: [
          { id: "t-11", title: "Variables, Types & Operators", description: "Understand JavaScript's type system including primitive types, type coercion.", type: "learn", estimatedTime: "2h", state: "completed", skills: ["JavaScript", "Fundamentals"] },
          { id: "t-12", title: "Functions, Scope & Closures", description: "Deep dive into JavaScript functions — declarations, expressions, arrow functions.", type: "learn", estimatedTime: "3h", state: "completed", dependsOn: ["t-11"], skills: ["JavaScript", "Functions", "Closures"] },
          { id: "t-13", title: "Arrays, Objects & Destructuring", description: "Master data structures in JavaScript. Learn array methods map, filter, reduce.", type: "practice", estimatedTime: "2.5h", state: "completed", dependsOn: ["t-12"], skills: ["JavaScript", "Data Structures"] },
          { id: "t-14", title: "DOM Manipulation & Events", description: "Bridge HTML and JavaScript by learning to select, create, and modify DOM elements.", type: "practice", estimatedTime: "3h", state: "completed", dependsOn: ["t-13"], skills: ["JavaScript", "DOM", "Events"] },
        ],
      },
      {
        id: "sub-2-2",
        title: "Asynchronous JavaScript",
        tasks: [
          { id: "t-15", title: "Callbacks & Promises", description: "Understand asynchronous programming in JavaScript.", type: "learn", estimatedTime: "2h", state: "completed", dependsOn: ["t-14"], skills: ["JavaScript", "Async", "Promises"] },
          { id: "t-16", title: "Async/Await & Error Handling", description: "Write clean asynchronous code with async/await syntax.", type: "learn", estimatedTime: "2h", state: "completed", dependsOn: ["t-15"], skills: ["JavaScript", "Async/Await"] },
          { id: "t-17", title: "Fetch API & HTTP Methods", description: "Make HTTP requests using the Fetch API.", type: "practice", estimatedTime: "2.5h", state: "skipped", dependsOn: ["t-16"], skills: ["JavaScript", "HTTP", "APIs"] },
        ],
      },
      {
        id: "sub-2-3",
        title: "Modern ES6+ Features",
        tasks: [
          { id: "t-18", title: "Modules, Template Literals & Spread", description: "Learn ES6 module system import/export, template literals, and spread operator.", type: "learn", estimatedTime: "2h", state: "available", isRecommended: true, dependsOn: ["t-16"], skills: ["JavaScript", "ES6+", "Modules"], resources: [{ title: "ES6 Features Overview", url: "https://es6-features.org/", type: "docs" }, { title: "JavaScript Modules Explained", url: "https://www.youtube.com/watch?v=cRHQNNcYf6s", type: "video" }] },
          { id: "t-19", title: "Map, Set, Symbols & Iterators", description: "Explore advanced ES6+ data structures and iteration protocols.", type: "learn", estimatedTime: "2h", state: "available", dependsOn: ["t-16"], skills: ["JavaScript", "ES6+", "Data Structures"] },
          { id: "t-20", title: "Build a Vanilla JS Task Manager", description: "Combine everything you've learned to build a complete task manager.", type: "project", estimatedTime: "6h", state: "locked", dependsOn: ["t-18", "t-19"], skills: ["JavaScript", "DOM", "Project"] },
        ],
      },
    ],
  },
  {
    id: "topic-3",
    title: "React & Frontend Engineering",
    subtopics: [
      {
        id: "sub-3-1",
        title: "React Fundamentals",
        tasks: [
          { id: "t-21", title: "JSX, Components & Props", description: "Understand JSX syntax, create functional components.", type: "learn", estimatedTime: "3h", state: "completed", dependsOn: ["t-18"], skills: ["React", "JSX", "Components"] },
          { id: "t-22", title: "State, Events & Conditional Rendering", description: "Master useState for managing component state.", type: "learn", estimatedTime: "3h", state: "locked", dependsOn: ["t-21", "t-18"], skills: ["React", "State", "Events"] },
          { id: "t-23", title: "Lists, Keys & Forms in React", description: "Render dynamic lists with proper key handling.", type: "practice", estimatedTime: "2.5h", state: "locked", dependsOn: ["t-22"], skills: ["React", "Forms", "Lists"] },
        ],
      },
      {
        id: "sub-3-2",
        title: "Advanced React Patterns",
        tasks: [
          { id: "t-24", title: "useEffect, useRef & Custom Hooks", description: "Handle side effects with useEffect.", type: "learn", estimatedTime: "4h", state: "locked", dependsOn: ["t-23"], skills: ["React", "Hooks", "Side Effects"] },
          { id: "t-25", title: "Context API & State Management", description: "Share state across components without prop drilling.", type: "learn", estimatedTime: "3h", state: "locked", dependsOn: ["t-24"], skills: ["React", "Context", "State Management"] },
          { id: "t-26", title: "React Router & Navigation", description: "Implement client-side routing with React Router v6.", type: "practice", estimatedTime: "2.5h", state: "locked", dependsOn: ["t-25"], skills: ["React", "Routing", "SPA"] },
          { id: "t-27", title: "Build a Full E-Commerce Frontend", description: "Build a production-quality e-commerce frontend.", type: "project", estimatedTime: "12h", state: "locked", dependsOn: ["t-26"], skills: ["React", "E-Commerce", "Full App"] },
        ],
      },
      {
        id: "sub-3-3",
        title: "TypeScript for React",
        tasks: [
          { id: "t-28", title: "Types, Interfaces & Generics", description: "Add type safety to your JavaScript with TypeScript.", type: "learn", estimatedTime: "3h", state: "locked", dependsOn: ["t-21"], skills: ["TypeScript", "Type Safety"] },
          { id: "t-29", title: "Typing Components, Props & Hooks", description: "Apply TypeScript to React components.", type: "practice", estimatedTime: "3h", state: "locked", dependsOn: ["t-28"], skills: ["TypeScript", "React", "Advanced Types"] },
        ],
      },
    ],
  },
  {
    id: "topic-4",
    title: "Node.js & Express Backend",
    subtopics: [
      {
        id: "sub-4-1",
        title: "Node.js Fundamentals",
        tasks: [
          { id: "t-30", title: "Node Runtime, Modules & NPM", description: "Understand Node.js as a JavaScript runtime.", type: "learn", estimatedTime: "2.5h", state: "locked", dependsOn: ["t-18"], skills: ["Node.js", "NPM", "Runtime"] },
          { id: "t-31", title: "File System, Streams & Buffers", description: "Work with the file system API, understand streams.", type: "learn", estimatedTime: "2h", state: "locked", dependsOn: ["t-30"], skills: ["Node.js", "File System", "Streams"] },
          { id: "t-32", title: "Build a CLI Tool with Node.js", description: "Create a command-line application.", type: "project", estimatedTime: "4h", state: "locked", dependsOn: ["t-31"], skills: ["Node.js", "CLI", "Project"] },
        ],
      },
      {
        id: "sub-4-2",
        title: "Express.js & REST APIs",
        tasks: [
          { id: "t-33", title: "Express Routing & Middleware", description: "Build HTTP servers with Express.js.", type: "learn", estimatedTime: "3h", state: "locked", dependsOn: ["t-30"], skills: ["Express.js", "Routing", "Middleware"] },
          { id: "t-34", title: "RESTful API Design Principles", description: "Design clean, predictable APIs following REST.", type: "learn", estimatedTime: "2h", state: "locked", dependsOn: ["t-33"], skills: ["REST", "API Design"] },
          { id: "t-35", title: "Request Validation & Error Handling", description: "Implement robust input validation.", type: "practice", estimatedTime: "2.5h", state: "locked", dependsOn: ["t-34"], skills: ["Express.js", "Validation", "Error Handling"] },
          { id: "t-36", title: "Build a Blog REST API", description: "Build a complete REST API for a blog platform.", type: "project", estimatedTime: "8h", state: "locked", dependsOn: ["t-35"], skills: ["Express.js", "REST", "Project"] },
        ],
      },
      {
        id: "sub-4-3",
        title: "Authentication & Security",
        tasks: [
          { id: "t-37", title: "JWT Tokens & Session Management", description: "Implement stateless authentication with JSON Web Tokens.", type: "learn", estimatedTime: "3h", state: "locked", dependsOn: ["t-34"], skills: ["JWT", "Authentication"] },
          { id: "t-38", title: "Bcrypt, CORS & Helmet.js", description: "Secure your API.", type: "practice", estimatedTime: "2h", state: "locked", dependsOn: ["t-37"], skills: ["Security", "Bcrypt", "CORS"] },
          { id: "t-39", title: "OAuth 2.0 & Social Login", description: "Implement third-party authentication.", type: "learn", estimatedTime: "3h", state: "locked", dependsOn: ["t-38"], skills: ["OAuth", "Passport.js", "Social Auth"] },
        ],
      },
    ],
  },
  {
    id: "topic-5",
    title: "MongoDB & Database Design",
    subtopics: [
      {
        id: "sub-5-1",
        title: "MongoDB Fundamentals",
        tasks: [
          { id: "t-40", title: "Documents, Collections & CRUD", description: "Learn MongoDB's document-based data model.", type: "learn", estimatedTime: "3h", state: "locked", dependsOn: ["t-34"], skills: ["MongoDB", "CRUD", "NoSQL"] },
          { id: "t-41", title: "Mongoose: Schemas & Models", description: "Use Mongoose as an ODM for MongoDB.", type: "learn", estimatedTime: "3h", state: "locked", dependsOn: ["t-40"], skills: ["Mongoose", "ODM", "Schemas"] },
          { id: "t-42", title: "Indexing, Aggregation & Pipelines", description: "Optimize query performance with indexes.", type: "practice", estimatedTime: "4h", state: "locked", dependsOn: ["t-41"], skills: ["MongoDB", "Indexing", "Aggregation"] },
        ],
      },
      {
        id: "sub-5-2",
        title: "Data Modeling Patterns",
        tasks: [
          { id: "t-43", title: "Embedding vs Referencing", description: "Make informed data modeling decisions.", type: "learn", estimatedTime: "2h", state: "locked", dependsOn: ["t-41"], skills: ["MongoDB", "Data Modeling"] },
          { id: "t-44", title: "Schema Design for E-Commerce", description: "Design a real-world database schema.", type: "practice", estimatedTime: "3h", state: "locked", dependsOn: ["t-43"], skills: ["MongoDB", "Schema Design", "E-Commerce"] },
          { id: "t-45", title: "Transactions & Data Integrity", description: "Implement multi-document transactions.", type: "learn", estimatedTime: "2h", state: "locked", dependsOn: ["t-44"], skills: ["MongoDB", "Transactions", "ACID"] },
        ],
      },
    ],
  },
  {
    id: "topic-6",
    title: "Full-Stack Integration & Deployment",
    subtopics: [
      {
        id: "sub-6-1",
        title: "Connecting Frontend to Backend",
        tasks: [
          { id: "t-46", title: "Axios & API Integration in React", description: "Connect your React frontend to your Express backend.", type: "learn", estimatedTime: "2.5h", state: "locked", dependsOn: ["t-26", "t-35"], skills: ["React", "Axios", "API Integration"] },
          { id: "t-47", title: "Environment Variables & Config", description: "Manage configuration across environments.", type: "learn", estimatedTime: "1h", state: "locked", dependsOn: ["t-46"], skills: ["DevOps", "Configuration"] },
          { id: "t-48", title: "Build a Full MERN CRUD App", description: "Build a complete application using MongoDB, Express, React, and Node.js.", type: "project", estimatedTime: "14h", state: "locked", dependsOn: ["t-47", "t-42"], skills: ["MERN", "Full Stack", "Capstone"] },
        ],
      },
      {
        id: "sub-6-2",
        title: "DevOps & Deployment",
        tasks: [
          { id: "t-49", title: "Docker Basics for MERN Apps", description: "Containerize your MERN application with Docker.", type: "learn", estimatedTime: "3h", state: "locked", dependsOn: ["t-48"], skills: ["Docker", "Containers", "DevOps"] },
          { id: "t-50", title: "Deploy to Vercel, Railway & AWS", description: "Deploy your applications to modern platforms.", type: "practice", estimatedTime: "4h", state: "locked", dependsOn: ["t-49"], skills: ["Deployment", "Cloud", "AWS"] },
          { id: "t-51", title: "CI/CD with GitHub Actions", description: "Automate your development workflow.", type: "learn", estimatedTime: "2.5h", state: "locked", dependsOn: ["t-50"], skills: ["CI/CD", "GitHub Actions", "Automation"] },
          { id: "t-52", title: "Capstone: Deploy Production MERN App", description: "Your final capstone — deploy a full production-ready MERN application.", type: "project", estimatedTime: "16h", state: "locked", dependsOn: ["t-51"], skills: ["MERN", "Production", "Capstone"] },
        ],
      },
    ],
  },
];

// ─── Selector simulation (in main project: roadmapSelectors.ts) ─────

const DIFFICULTIES = ["Beginner", "Beginner", "Intermediate", "Intermediate", "Advanced", "Advanced"];

function parseHours(time: string): number {
  return parseFloat(time) || 0;
}

function buildTaskMap(topics: RawTopic[]): Map<string, RawTask> {
  const map = new Map<string, RawTask>();
  for (const t of topics) for (const s of t.subtopics) for (const task of s.tasks) map.set(task.id, task);
  return map;
}

function findUnlockedBy(taskId: string, topics: RawTopic[]): string[] {
  const result: string[] = [];
  for (const t of topics) for (const s of t.subtopics) for (const task of s.tasks) {
    if (task.dependsOn?.includes(taskId)) result.push(task.title);
  }
  return result;
}

function getTopicNarrative(title: string, progress: number, completed: number, total: number, available: number): string {
  if (completed === total) return `✅ ${title} — Complete! Well done.`;
  if (completed === 0 && available === 0) return "";
  if (progress >= 75) return `Almost there — ${total - completed} tasks left in ${title} 🏁`;
  if (progress >= 50) return `You're over halfway through ${title} 🚀`;
  if (progress >= 25) return `Good momentum in ${title} — keep going 💪`;
  if (completed > 0) return `You've started ${title} — ${completed} down, ${total - completed} to go`;
  if (available > 0) return `Ready to start ${title} — ${available} tasks available`;
  return "";
}

function toTaskView(task: RawTask, order: number, taskMap: Map<string, RawTask>): TaskView {
  let dependencyHint: string | undefined;
  if (task.state === "locked" && task.dependsOn) {
    const incomplete = task.dependsOn
      .map(id => { const t = taskMap.get(id); return t && t.state !== "completed" ? t.title : null; })
      .filter(Boolean) as string[];
    if (incomplete.length === 1) dependencyHint = `Complete "${incomplete[0]}" to unlock`;
    else if (incomplete.length > 1) dependencyHint = `Complete "${incomplete[0]}" and ${incomplete.length - 1} more to unlock`;
  }
  return {
    id: task.id,
    title: task.title,
    type: task.type,
    state: task.state,
    estimatedTime: task.estimatedTime,
    isRecommended: task.isRecommended || false,
    dependencyHint,
    isLoading: false,
    order,
  };
}

function toTopicViews(topics: RawTopic[]): TopicView[] {
  const taskMap = buildTaskMap(topics);
  const activeTopicId = topics.find(t => t.subtopics.some(s => s.tasks.some(tk => tk.state === "available")))?.id || null;

  return topics.map((topic, topicIdx): TopicView => {
    const allTasks = topic.subtopics.flatMap(s => s.tasks);
    const total = allTasks.length;
    const completed = allTasks.filter(t => t.state === "completed").length;
    const available = allTasks.filter(t => t.state === "available").length;
    const progress = Math.round((completed / total) * 100);
    const isActive = topic.id === activeTopicId;

    const subtopics: SubtopicView[] = topic.subtopics.map((sub, subIdx): SubtopicView => {
      const subCompleted = sub.tasks.filter(t => t.state === "completed").length;
      const subProgress = sub.tasks.length > 0 ? Math.round((subCompleted / sub.tasks.length) * 100) : 0;
      return {
        id: sub.id,
        title: sub.title,
        progress: subProgress,
        completedCount: subCompleted,
        totalCount: sub.tasks.length,
        hasAvailableTasks: sub.tasks.some(t => t.state === "available" || (t.isRecommended && t.state !== "completed")),
        tasks: sub.tasks.map((task, taskIdx) => toTaskView(task, taskIdx, taskMap)),
        order: subIdx,
      };
    });

    return {
      id: topic.id,
      title: topic.title,
      difficulty: DIFFICULTIES[topicIdx] || "Advanced",
      progress,
      totalTasks: total,
      completedTasks: completed,
      availableTasks: available,
      narrative: getTopicNarrative(topic.title, progress, completed, total, available),
      isActive,
      isLocked: progress === 0 && !isActive,
      subtopics,
      order: topicIdx,
    };
  });
}

function getUnlockedSkills(topics: RawTopic[]): string[] {
  const skillMap: Record<string, { done: number; total: number }> = {};
  for (const t of topics) for (const s of t.subtopics) for (const task of s.tasks) {
    for (const skill of (task.skills ?? [])) {
      if (!skillMap[skill]) skillMap[skill] = { done: 0, total: 0 };
      skillMap[skill].total++;
      if (task.state === "completed") skillMap[skill].done++;
    }
  }
  return Object.entries(skillMap).filter(([, v]) => v.total >= 2 && v.done === v.total).map(([k]) => k);
}

// ─── Public hook for dev adapter ─────────────────────────────────────

export function useMockAdapter(): { data: RoadmapPageProps } {
  const [topics, setTopics] = useState(INITIAL_ROADMAP);
  const [bookmarks, setBookmarks] = useState<Set<string>>(new Set());
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null);
  const [focusTaskId, setFocusTaskId] = useState<string | null>(null);
  const [showConfetti, setShowConfetti] = useState(false);
  const [toast, setToast] = useState<{ message: string; visible: boolean; variant: "success" | "info" | "skill" } | null>(null);
  const [lastInteractedTaskId, setLastInteractedTaskId] = useState<string | null>(null);
  const [streak, setStreak] = useState(3);
  const [todayCompleted, setTodayCompleted] = useState(0);

  const taskMap = useMemo(() => buildTaskMap(topics), [topics]);

  const showToast = useCallback((msg: string, variant: "success" | "info" | "skill" = "success") => {
    setToast({ message: msg, visible: true, variant });
    setTimeout(() => setToast(null), 2600);
  }, []);

  const updateTaskState = useCallback((taskId: string, newState: TaskState) => {
    setTopics(prev => {
      let updated = prev.map(topic => ({
        ...topic,
        subtopics: topic.subtopics.map(sub => ({
          ...sub,
          tasks: sub.tasks.map(task => task.id === taskId ? { ...task, state: newState } : task),
        })),
      }));

      const allTasks = updated.flatMap(t => t.subtopics.flatMap(s => s.tasks));
      const tMap = new Map<string, RawTask>(allTasks.map(t => [t.id, t]));

      // Unlock
      updated = updated.map(topic => ({
        ...topic,
        subtopics: topic.subtopics.map(sub => ({
          ...sub,
          tasks: sub.tasks.map(task => {
            if (task.state !== "locked" || !task.dependsOn || task.dependsOn.length === 0) return task;
            const allDepsMet = task.dependsOn.every(depId => { const dep = tMap.get(depId); return dep && dep.state === "completed"; });
            return allDepsMet ? { ...task, state: "available" as TaskState } : task;
          }),
        })),
      }));

      // Reassign recommended
      const allUpdated = updated.flatMap(t => t.subtopics.flatMap(s => s.tasks));
      const currentRec = allUpdated.find(t => t.isRecommended);
      if (!currentRec || currentRec.state === "completed" || currentRec.state === "skipped") {
        const nextRec = allUpdated.find(t => t.state === "available" && !t.isRecommended);
        updated = updated.map(topic => ({
          ...topic,
          subtopics: topic.subtopics.map(sub => ({
            ...sub,
            tasks: sub.tasks.map(task => ({ ...task, isRecommended: nextRec ? task.id === nextRec.id : false })),
          })),
        }));
      }

      return updated;
    });
  }, []);

  const onAction = useCallback(async (action: RoadmapAction): Promise<ActionResult> => {
    switch (action.type) {
      case "complete": {
        updateTaskState(action.taskId, "completed");
        if (selectedTaskId === action.taskId) {
          // Keep panel open to show "completed" state
        }
        const newCount = todayCompleted + 1;
        setTodayCompleted(newCount);
        if (newCount === 1) setStreak(prev => prev + 1);
        setShowConfetti(true);
        setTimeout(() => setShowConfetti(false), 1800);

        const task = taskMap.get(action.taskId);
        const prevSkills = getUnlockedSkills(topics);
        // We need to compute after state update; simplified for dev
        showToast(`+1 completed — "${task?.title || "task"}"`, "success");
        return { success: true };
      }
      case "skip": {
        const task = taskMap.get(action.taskId);
        updateTaskState(action.taskId, "skipped");
        if (focusTaskId === action.taskId) setFocusTaskId(null);
        showToast(`Skipped — "${task?.title || "task"}"`, "info");
        return { success: true };
      }
      case "unskip": {
        const task = taskMap.get(action.taskId);
        updateTaskState(action.taskId, "available");
        showToast(`Restored — "${task?.title || "task"}"`, "info");
        return { success: true };
      }
      case "bookmark": {
        setBookmarks(prev => {
          const next = new Set(prev);
          if (next.has(action.taskId)) next.delete(action.taskId);
          else next.add(action.taskId);
          return next;
        });
        return { success: true };
      }
      case "open": {
        setSelectedTaskId(action.taskId);
        setLastInteractedTaskId(action.taskId);
        return { success: true };
      }
      case "close-panel": {
        setSelectedTaskId(null);
        return { success: true };
      }
      case "focus": {
        setSelectedTaskId(null);
        setFocusTaskId(action.taskId);
        setLastInteractedTaskId(action.taskId);
        return { success: true };
      }
      case "exit-focus": {
        setFocusTaskId(null);
        return { success: true };
      }
      case "focus-next": {
        if (!focusTaskId) return { success: true };
        const all = topics.flatMap(t => t.subtopics.flatMap(s => s.tasks));
        const available = all.filter(t => t.state === "available" && t.id !== focusTaskId);
        const next = available.find(t => t.isRecommended) || available[0];
        if (next) {
          setFocusTaskId(next.id);
          setLastInteractedTaskId(next.id);
        } else {
          setFocusTaskId(null);
        }
        return { success: true };
      }
      case "resume": {
        if (lastInteractedTaskId) setSelectedTaskId(lastInteractedTaskId);
        return { success: true };
      }
      case "scroll-to-recommended": {
        return { success: true }; // Handled by RoadmapPage
      }
      default:
        return { success: false, error: "Unknown action" };
    }
  }, [updateTaskState, selectedTaskId, focusTaskId, todayCompleted, taskMap, topics, showToast, lastInteractedTaskId]);

  // ── Build ViewModels ──

  const topicViews = useMemo(() => toTopicViews(topics), [topics]);
  const allTasks = useMemo(() => topics.flatMap(t => t.subtopics.flatMap(s => s.tasks)), [topics]);
  const totalTasks = allTasks.length;
  const completedCount = allTasks.filter(t => t.state === "completed").length;
  const availableCount = allTasks.filter(t => t.state === "available").length;
  const remainingHours = allTasks.filter(t => t.state !== "completed" && t.state !== "skipped").reduce((s, t) => s + parseHours(t.estimatedTime), 0);
  const recommendedTask = allTasks.find(t => t.isRecommended);

  // Build selected task detail view
  const selectedTask: TaskDetailView | null = useMemo(() => {
    if (!selectedTaskId) return null;
    const raw = taskMap.get(selectedTaskId);
    if (!raw) return null;
    const depNames = (raw.dependsOn ?? []).map(id => {
      const dep = taskMap.get(id);
      return { id, title: dep?.title ?? id, met: dep?.state === "completed" };
    });
    return {
      ...toTaskView(raw, 0, taskMap),
      description: raw.description,
      resources: raw.resources ?? [],
      skills: raw.skills ?? [],
      prerequisites: depNames,
      unlocks: findUnlockedBy(raw.id, topics),
      isBookmarked: bookmarks.has(raw.id),
    };
  }, [selectedTaskId, taskMap, topics, bookmarks]);

  // Build focus task view
  const focusTask: FocusTaskView | null = useMemo(() => {
    if (!focusTaskId) return null;
    const raw = taskMap.get(focusTaskId);
    if (!raw) return null;
    const available = allTasks.filter(t => t.state === "available" && t.id !== focusTaskId);
    const next = available.find(t => t.isRecommended) || available[0];
    return {
      id: raw.id,
      title: raw.title,
      type: raw.type,
      estimatedTime: raw.estimatedTime,
      description: raw.description,
      skills: raw.skills ?? [],
      unlocks: findUnlockedBy(raw.id, topics),
      isRecommended: raw.isRecommended || false,
      resources: raw.resources ?? [],
      nextTask: next ? { id: next.id, title: next.title } : null,
    };
  }, [focusTaskId, taskMap, topics, allTasks]);

  // Momentum
  const momentum: MomentumView | null = useMemo(() => {
    if (todayCompleted >= 3) return { message: "You're on fire! 3+ tasks today", emoji: "🔥", taskCount: todayCompleted };
    if (todayCompleted >= 2) return { message: "Great momentum — 2 tasks done today!", emoji: "⚡", taskCount: todayCompleted };
    if (todayCompleted === 1 && streak >= 3) return { message: `${streak}-day streak! Keep it going`, emoji: "🔥", taskCount: todayCompleted };
    if (todayCompleted === 1) return { message: "Nice start — 1 task down today", emoji: "✨", taskCount: todayCompleted };
    return null;
  }, [todayCompleted, streak]);

  // Daily plan
  const dailyPlan: DailyPlanView = useMemo(() => {
    const available = allTasks.filter(t => t.state === "available");
    if (available.length === 0) return { tasks: [], reasoning: "", totalTime: "0h" };

    const easy = available.filter(t => t.type === "learn" && parseHours(t.estimatedTime) <= 2);
    const medium = available.filter(t => t.type === "practice" || (t.type === "learn" && parseHours(t.estimatedTime) > 2));
    const hard = available.filter(t => t.type === "project");

    const plan: RawTask[] = [];
    let remaining = 2.5;

    const rec = available.find(t => t.isRecommended);
    if (rec) { plan.push(rec); remaining -= parseHours(rec.estimatedTime); }

    const easyPick = easy.find(t => !plan.some(p => p.id === t.id));
    if (easyPick && parseHours(easyPick.estimatedTime) <= remaining) { plan.push(easyPick); remaining -= parseHours(easyPick.estimatedTime); }

    const medPick = medium.find(t => !plan.some(p => p.id === t.id));
    if (medPick && remaining >= 1) { plan.push(medPick); remaining -= parseHours(medPick.estimatedTime); }

    if (plan.length < 3 && remaining >= 2) {
      const projPick = hard.find(t => !plan.some(p => p.id === t.id));
      if (projPick) plan.push(projPick);
    }

    const types = plan.map(t => t.type);
    const parts: string[] = [];
    if (types.includes("learn")) parts.push("1 concept to learn");
    if (types.includes("practice")) parts.push("1 hands-on practice");
    if (types.includes("project")) parts.push("1 project (stretch goal)");
    if (parts.length === 0 && plan.length > 0) parts.push(`${plan.length} task${plan.length > 1 ? "s" : ""} to build momentum`);

    const totalTime = plan.reduce((s, t) => s + parseHours(t.estimatedTime), 0);
    const DIFF: Record<TaskType, "Easy" | "Medium" | "Stretch"> = { learn: "Easy", practice: "Medium", project: "Stretch" };

    return {
      tasks: plan.slice(0, 3).map((t, i) => ({
        id: t.id,
        title: t.title,
        type: t.type,
        estimatedTime: t.estimatedTime,
        difficulty: DIFF[t.type],
        order: i,
      })),
      reasoning: "Based on your progress: " + parts.join(" → "),
      totalTime: `${totalTime}h`,
    };
  }, [allTasks]);

  // Weekly summary
  const weeklySummary: WeeklySummaryView = useMemo(() => {
    const weeklyCompleted = 12 + todayCompleted;
    return {
      tasksCompleted: weeklyCompleted,
      vsLastWeek: weeklyCompleted - 10,
      unlockedSkills: getUnlockedSkills(topics),
    };
  }, [todayCompleted, topics]);

  // Last task
  const lastTask = useMemo(() => {
    if (!lastInteractedTaskId) return null;
    const raw = taskMap.get(lastInteractedTaskId);
    if (!raw || raw.state !== "available") return null;
    return { id: raw.id, title: raw.title, type: raw.type };
  }, [lastInteractedTaskId, taskMap]);

  const data: RoadmapPageProps = {
    topics: topicViews,
    progress: {
      percentage: totalTasks > 0 ? Math.round((completedCount / totalTasks) * 100) : 0,
      completed: completedCount,
      total: totalTasks,
      available: availableCount,
      remainingHours,
    },
    dailyPlan,
    momentum,
    weeklySummary,
    streak: { days: streak, todayCompleted, todayGoal: 2 },
    lastTask,
    selectedTask,
    focusTask,
    recommendedTaskId: recommendedTask?.id ?? null,
    isUpdatingTaskIds: new Set(),
    showConfetti,
    toast,
    onAction,
  };

  return { data };
}
