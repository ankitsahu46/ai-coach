/**
 * App.tsx — Dev-only adapter shell.
 *
 * ❌ This file does NOT ship to the main project.
 * ✅ It provides the mock adapter so `npm run dev` works standalone.
 *
 * Main project instead does:
 *   const { data, onAction } = useRoadmapGeneration();
 *   <RoadmapPage {...data} onAction={onAction} />
 */

import { RoadmapPage } from "./components/RoadmapPage";
import { useMockAdapter } from "./dev/useMockAdapter";

export default function App() {
  const { data } = useMockAdapter();
  return <RoadmapPage {...data} />;
}
